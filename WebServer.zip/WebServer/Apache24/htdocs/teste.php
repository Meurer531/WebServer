<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teste</title>
</head>
<body>

<form method="post" action="teste.php">
    <table>
    <tr>
        <td><label>Login</label></td>
        <td><input type="text" name="lg"></td>
    </tr>


    <tr>
        <td><label>Senha</label></td>
        <td><input type="password" name="pass" /></td>
    </tr>

    <tr>
        <td align="right" colspan="2"><input type="submit" value="Entrar" name="Entrar"></td>
    </tr>
        </table>
    </form>
</body>
</html>

<?php

extract($_POST);
if(isset($_POST["Entrar"]))
{
    include_once("Conect.php");
    $obj = new Conect();
    $resultado = $obj->ConectarBanco();
}

?>