<?php



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="cadastro1.css">

</head>

<body>

    <footer><a href="agenda.php"><img style="margin-top: -5px;width: 30px; height: 30px;" src="sair.png" alt="">Sair</footer></a>

    <form action="cadastrar.php" method="post">


        <h1 class="titu">Cadastro de Usuário</h1>

        <div class="central">


            <table class="textta">
                <tr>
                    <td coslpan="2">&nbsp;</td>
                </tr>

                <tr>
                    <td><label for="">Nome: </label></td>
                    <td><input required placeholder="Nome" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Endereço: </label></td>
                    <td><input required placeholder="Endereço" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Email: </label></td>
                    <td><input required placeholder="Email" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Cidade: </label></td>
                    <td><input required placeholder="Cidade" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Telefone: </label></td>
                    <td><input required placeholder="Telefone" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Nome Login: </label></td>
                    <td><input required placeholder="Nome Login" type="text"></td>
                </tr>
            </table>
    </form>

    </div>


</body>

</html>