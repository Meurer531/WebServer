<?php
    print("Oi, eu sou teste php<br />");

    echo "imprimido";


?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>seila</title>

    <style type="text/css" rel="styleheet">
       
       h1{
        color: red;
       }

       p{
        color: blue;
        font-size: 150px;
       }
    </style>
</head>
<body>
    
oi, esse é meu teste


    <?php
   
   $var = 10;
   $var2 = 20.5;
   $soma = $var+$var2;

   for($i=0; $i<100; $i++)
   {
        echo "<li> %i </li>";
   }
   echo "<ul>";

   echo "<p>$soma</p>";

   print("<h1>Olá Mundo!</h1><br />");

       echo "imprimido";
?>

</body>
</html>

