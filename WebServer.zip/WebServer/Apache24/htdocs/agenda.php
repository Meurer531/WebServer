<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="agenda.css">
    <title>Login</title>
</head>

<body>

    <form method="post" action="agenda.php">

        <form action="login2">
            <div class="central">
                <table>
                    <tr>
                        <td colspan="2">&nbsp;</td>
                    </tr>
                    <tr>
                        <td style="text-align: center;" colspan="2">
                            <img src="rt.png" alt="" width="20%">
                        </td>
                    </tr>
                    <tr class="login">
                        <td><label for="">Login:</label></td>
                        <td><input name="nome" class="iimg" maxlength="15" type="text"></td>

                    </tr>

                    <tr class="login">
                        <td><label for="">Password:</label></td>
                        <td><input class="iimgg" type="password"></td>
                    </tr>

                    <tr>
                        <td style="text-align: center; margin-top: 30px" colspan="2">
                            <a href=""><button class="b" name="Confirmar" type="subimit">Confirmar</button></a>
                        </td>
                    </tr>

                    <tr>
                        <td style="text-align: center;" colspan="2">
                            <a href="cadastrar.php"><button class="b" name="Cadastrar" type="button">Cadastrar</button></a>
                        </td>




                    </tr>
                    <tr>
                        <td colspan="2">&nbsp;</td>
                    </tr>
                </table>
                <div style="clear:both;">&nbsp;</div>

            </div>


        </form>


</body>

</html>


<?php

extract($_POST);

if (isset($_POST["Confirmar"])) {

    $a = $_POST["nome"];

    echo $a;
}

?>