<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="agenda.css">
    <title>Document</title>
</head>
<body>
    

    <form action="login2">
        <div class="central">
             <table class="">
                <tr>
                    <td style="text-align: center;" colspan="2">
                        <img src="rt.png" alt=""  width="20%">
                    </td>
                </tr>
                <tr class="login">
                    <td><label for="">Login:</label></td>
                    <td><input class="iimg" maxlength="15" type="text"></td>
                    
                </tr>

                <tr class="login">
                    <td><label for="">Password:</label></td>
                    <td><input type="password"></td>
                </tr>

             </table>
             <div style="clear:both;">&nbsp;</div>
        </div>


    </form>


</body>
</html>